<!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-4 text-gray-800">Detail</h1>

           <table border="1" cellpadding="10" id="table" class="table table-bordered table-hover table-stripped display nowrap">
               
               <thead>
                 <th>No</th>
                 <th>No Anggota</th>
                 <th>No Polisi</th>
                 <th>No Uji Kir</th>
                 <th>Nama Pemilik</th>
                 <th>Alamat Pemilik</th>
                 <th>No HP</th>
                 <th>Merk</th>
                 <th>Warna/Tahun</th>
                 <th>No Rangka</th>
                 <th>No Mesin</th>
                 <th>Trayek</th>
                 <th>Keterangan</th>
                 <th>Action</th>
               </thead>
               <?php $nomor=1; ?>
               <?php foreach ($anggota as $a): ?>
                 <tr>
                   <td><?= $nomor; ?></td>
                   <td><?= $a['no_anggota'] ?></td>
                   <td><?= $a['no_polisi'] ?></td>
                   <td><?= $a['no_uji_kir'] ?></td>
                   <td><?= $a['nama_pemilik'] ?></td>
                   <td><?= $a['alamat_pemilik'] ?></td>
                   <td><?= $a['no_hp'] ?></td>
                   <td><?= $a['merk_type'] ?></td>
                   <td><?= $a['warna_tahun'] ?></td>
                   <td><?= $a['no_rangka'] ?></td>
                   <td><?= $a['no_mesin'] ?></td>
                   <td><?= $a['trayek_jalur'] ?></td>
                   <td><?= $a['keterangan'] ?></td>
                   <td>
                     <a class="btn-sm btn-danger" id="btn-hapus" href="<?= base_url('admin/hapus') ?>/<?= $a['id'] ?>"><i class="fa fa-trash"aria-hidden="true"></i></a>
                     <a class="btn-sm btn-info" href="<?= base_url('admin/detail') ?>/<?= $a['id'] ?>"><i class="fa fa-info-circle"aria-hidden="true"></i></a>
                     <a class="btn-sm btn-warning" href="<?= base_url('admin/edit') ?>/<?= $a['id'] ?>"><i class="fa fa-edit" aria-hidden="true"></i></a>
                   </td>
                 </tr>
                 <?php $nomor++; ?>
               <?php endforeach ?>
              </table> 

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content --> 