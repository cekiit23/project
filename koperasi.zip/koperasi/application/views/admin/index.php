
 
        <style type="text/css">
          table{
            border: 1px solid black;
            width: 1000px;
            }

         th{
                width: 900px;
            }
        </style>
        

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
          </div>

            <div class="row">
              <div class="col-md-12">

                <div class="flash-data" data-flashdata="<?= $this->session->flashdata('flash'); ?>"></div>
                <?php if($this->session->flashdata('flash') ) : ?>
  
                <?php endif; ?>
                <div class="mb-3">
                <a href="" class="btn btn-primary"><i class="fa fa-file-pdf" aria-hidden="true"></i></a>
                <a href="<?= base_url('export/excel') ?>" class="btn btn-warning"><i class="fa fa-file-excel" aria-hidden="true"></i></a>
                <a href="" class="btn btn-danger"><i class="fa fa-print" aria-hidden="true"></i></a>
              </div>
                    <!-- /.container-fluid -->
             <table border="1" cellpadding="10" id="table" class="table table-bordered table-hover table-stripped display nowrap">
               
               <thead>
                 <th>No</th>
                 <th>No Anggota</th>
                 <th>No Polisi</th>
                 <th>No Uji Kir</th>
                 <th>Nama Pemilik</th>
                 <th>Alamat Pemilik</th>
                 <th>No HP</th>
                 <th>Merk</th>
                 <th>Warna/Tahun</th>
                 <th>No Rangka</th>
                 <th>No Mesin</th>
                 <th>Trayek</th>
                 <th>Keterangan</th>
                 <th>Action</th>
               </thead>
               <?php $nomor=1; ?>
               <?php foreach ($anggota as $a): ?>
                 <tr>
                   <td><?= $nomor; ?></td>
                   <td><?= $a['no_anggota'] ?></td>
                   <td><?= $a['no_polisi'] ?></td>
                   <td><?= $a['no_uji_kir'] ?></td>
                   <td><?= $a['nama_pemilik'] ?></td>
                   <td><?= $a['alamat_pemilik'] ?></td>
                   <td><?= $a['no_hp'] ?></td>
                   <td><?= $a['merk_type'] ?></td>
                   <td><?= $a['warna_tahun'] ?></td>
                   <td><?= $a['no_rangka'] ?></td>
                   <td><?= $a['no_mesin'] ?></td>
                   <td><?= $a['trayek_jalur'] ?></td>
                   <td><?= $a['keterangan'] ?></td>
                   <td>
                     <a class="btn-sm btn-danger" id="btn-hapus" href="<?= base_url('admin/hapus') ?>/<?= $a['id'] ?>"><i class="fa fa-trash"aria-hidden="true"></i></a>
                     <a class="btn-sm btn-info" href="<?= base_url('admin/detail') ?>/<?= $a['id'] ?>"><i class="fa fa-info-circle"aria-hidden="true"></i></a>
                     <a class="btn-sm btn-warning" href="<?= base_url('admin/edit') ?>/<?= $a['id'] ?>"><i class="fa fa-edit" aria-hidden="true"></i></a>
                   </td>
                 </tr>
                 <?php $nomor++; ?>
               <?php endforeach ?>
              </table> 
             </div>      
      </div>
    </div>
      <!-- End of Main Content -->

      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; Koperasi Usaha Karya Mandiri 2020</span>
          </div>
        </div>
    
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="login.html">Logout</a>
        </div>
      </div>
    </div>
  </div>
</div>
  