
        

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Ubah Data</h1>
          </div>

            <div class="row">
              <div class="col-md-12">
                    <!-- /.container-fluid -->
             <form action="" method="post">
              <?php foreach($a as $anggota) :?>
              <input type="hidden" name="id" value="<?= $anggota['id'] ?>">
              <div class="form-group">  
              <label for="no_anggota">Nomor Anggota</label>
              <input type="text" name="no_anggota" class="form-control" id="no_anggota" value="<?= $anggota['no_anggota']; ?>">
              <small id="emailHelp" class="form-text text-danger"><?= form_error('no_anggota'); ?></small>
              </div>
              <div class="form-group">  
              <label for="no_polisi">Nomor Polisi</label>
              <input type="text" name="no_polisi" class="form-control" id="no_polisi" value="<?= $anggota['no_polisi']; ?>">
                <small id="emailHelp" class="form-text text-danger"><?= form_error('no_polisi'); ?></small>
              </div>
              <div class="form-group">  
              <label for="no_uji_kir">Nomor Uji Kir</label>
              <input type="text" name="no_uji_kir" class="form-control" id="no_uji_kir" value="<?= $anggota['no_uji_kir']; ?>">
              <small id="emailHelp" class="form-text text-danger"><?= form_error('no_uji_kir'); ?></small>
              </div>
              <div class="form-group">  
              <label for="nama_pemilik">Nama Pemilik</label>
              <input type="text" name="nama_pemilik" class="form-control" id="nama_pemilik" value="<?= $anggota['nama_pemilik']; ?>">
              <small id="emailHelp" class="form-text text-danger"><?= form_error('nama_pemilik'); ?></small>
              </div>
              <div class="form-group">  
              <label for="alamat_pemilik">Alamat Pemilik</label>
              <input type="text" name="alamat_pemilik" class="form-control" id="alamat_pemilik" value="<?= $anggota['alamat_pemilik']; ?>">
              <small id="emailHelp" class="form-text text-danger"><?= form_error('alamat_pemilik'); ?></small>
              </div>
              <div class="form-group">  
              <label for="no_hp">Nomor Handphone</label>
              <input type="text" name="no_hp" class="form-control" id="no_hp" value="<?= $anggota['no_hp']; ?>">
              <small id="emailHelp" class="form-text text-danger"><?= form_error('no_hp'); ?></small>
              </div>
            <div class="form-group">  
              <label for="merk_type">Merk / Type</label>
              <input type="text" name="merk_type" class="form-control" id="merk_type" value="<?= $anggota['merk_type']; ?>">
              <small id="emailHelp" class="form-text text-danger"><?= form_error('merk_type'); ?></small>
              </div>
              <div class="form-group">  
              <label for="warna_tahun">Warna / Tahun</label>
              <input type="text" name="warna_tahun" class="form-control" id="warna_tahun" value="<?= $anggota['warna_tahun']; ?>">
              <small id="emailHelp" class="form-text text-danger"><?= form_error('warna_tahun'); ?></small>
              </div>
              <div class="form-group">  
              <label for="no_rangka">Nomor Rangka</label>
              <input type="text" name="no_rangka" class="form-control" id="no_rangka" value="<?= $anggota['no_rangka']; ?>">
              <small id="emailHelp" class="form-text text-danger"><?= form_error('no_rangka'); ?></small>
              </div>
              <div class="form-group">  
              <label for="no_mesin">Nomor Mesin</label>
              <input type="text" name="no_mesin" class="form-control" id="no_mesin" value="<?= $anggota['no_mesin']; ?>">
              <small id="emailHelp" class="form-text text-danger"><?= form_error('no_mesin'); ?></small>
              </div>
              <div class="form-group">  
              <label for="trayek_jalur">Trayek / Jalur</label>
              <select class="form-control" name="trayek_jalur" value="<?= $anggota['trayek_jalur']; ?>">
                <option value="<?= $anggota['trayek_jalur']; ?>"><?= $anggota['trayek_jalur'] ?></option>
                <option value="Padalarang - Rajamandala">PDL - RAJA</option>
                <option value="Padalarang - Cikalong - Cipendeuy">PDL - CKL - CPNDY</option>
                <option value="Padalarang - Gunung Bentang">PDL - GN.BENTANG</option>
                <option value="Padalarang - Parongpong">PDL - PARONGPONG</option>
                <option value="Cililin - Sindangkerta - Gunung Halu">CILILIN - SNDGKERTA - GN.HALU</option>
                <option value="Cilin - Cijenuk - Baranangsiang">CILILIN - CIJENUK - BARANANGSIANG</option>
                <option value="Lembang - Maribaya - Cibodas">LMBNG - MARIBAYA - CIBODAS</option>
                <option value="Lembang - Cikole">LMBNG - CIKOLE</option>
                <option value="Lembang - Cisarua">LMNBG - CISARUA</option>
                <option value="Cimahi - Cimareme - Batujajar - Cililin">CMH - CIMAREME - BATUJAJAR - CILILIN</option>
                <option value="Cimahi - Cimareme - Batujajar  ">CMH - CIMAREME - BATUJAJAR</option>
                <option value="Cimahi - Ciwaruga">CMH - CIWARUGA</option>
                <option value="Cimahi - Padalarang">CMH - PADALARANG</option>
                <option value="Cimahi - Parongpong">CMH - PARONGPONG</option>
                <option value="Cimahi - Cisarua">CMH - CISARUA</option>
                <option value="Cimahi - Cidahu - Tanimulya">CMH - CIDAHU - TANIMULYA</option>
                
                <option value="Cimahi - Nanjung - Cipatik">CMH - NANJUNG - CIPATIK</option>
                <option value="Soreang - Cipatik - Cililin">SOREANG - CIPATIK - CILILIN</option>
                <option value="Cilame - G.BukitRy - H.Gofur - Kolmas - Pasar Atas - Sangkuriang">CILAME - GBR - GOFUR - KOLMAS - P.ATAS</option>
                <option value="Cipeundeuy - Plered">CPNDY - PLDRED</option>
                <option value="St.Hall - Cimahi - Padalarang">STHALL - CMH - PDL
                <option value="Leuwi Panjang - Cimahi - Padalarang">LW.PANJANG - CMH - PDL</option>
                <option value="Bandung - Ciroyom - Cililin - Gn.Halu">BDG - ROYOM - CILILIN - GN.HALU</option>
                <option value="Cangkorah - Lw.Gajah - Baros">CANGKORAH - LW.GAJAH -</option>

              </select>
              <small id="emailHelp" class="form-text text-danger"><?= form_error('trayek_jalur'); ?></small>
              </div>
             <div class="form-group"> 
              <label for="keterangan">Keterangan</label>
              <select class="form-control" name="keterangan" value="<?= $anggota['keterangan']; ?>">
                <option value="<?= $anggota['keterangan']; ?>"><?= $anggota['keterangan'] ?></option>
                <option value="ganti pemilik">ganti Pemilik</option>
                <option value="diremajakan">diremajakan</option>
                <option value="keluar">mutasi</option>
                <option value="tidak aktif">tidak aktif</option>
                
                </select>
                <small id="emailHelp" class="form-text text-danger"><?= form_error('keterangan'); ?></small>
              </div>
              <button class="btn btn-success" type="submit" name="submit">submit</button>
             </form>
             </div>    
            <?php endforeach; ?>  
      </div>
    </div>
      <!-- End of Main Content -->

      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; Your Website 2019</span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="login.html">Logout</a>
        </div>
      </div>
    </div>
  </div>

  