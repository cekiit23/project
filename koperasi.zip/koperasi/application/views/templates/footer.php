<!-- Bootstrap core JavaScript-->
  <script src="<?= BASE_URL() ?>assets/vendor/jquery/jquery.min.js"></script>
  <script src="<?= BASE_URL() ?>assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="<?= BASE_URL() ?>assets/vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="<?= BASE_URL() ?>assets/js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->

  <script src="<?= BASE_URL() ?>assets/vendor/datatables/jquery.dataTables.js"></script>
  <script src="<?= BASE_URL() ?>assets/vendor/datatables/dataTables.bootstrap4.js"></script>
  <script type="text/javascript" src="<?= base_url() ?>assets/js/sweetalert2.all.min.js"></script>
  <script src="<?= BASE_URL() ?>assets/js/highcharts.js"></script>
   <script type="text/javascript" charset="utf-8">
            $(document).ready(function(){
                $('#table').dataTable({

                    
                    "sPaginationType":"full_numbers",
                    "aaSorting":[[2, "desc"]],
                    "bJQueryUI":true,
                    "scrollX": true,
                    "info" : false

                });

                const flashData = $('.flash-data').data('flashdata');


                if (flashData) {
                  Swal.fire(
                    'Data Anggota',
                    'Berhasil ' + flashData,
                    'success'
                    )
                }

                const tombolhapus = $('#btn-hapus').on('click', function(e)
                {


                  const href = $(this).attr('href');
                  e.preventDefault();

                  Swal.fire({
                  title: 'Apakah Anda Yakin ',
                  text: "Ingin Menghapus Data Ini ?",
                  icon: 'warning',
                  showCancelButton: true,
                  confirmButtonColor: '#3085d6',
                  cancelButtonColor: '#d33',
                  confirmButtonText: 'Ya,Hapus Saja'
                }).then((result) => {
                  if (result.value) {
                    document.location.href = href;
                  }
                })

                })

            });


            
        </script>

</body>

</html>
