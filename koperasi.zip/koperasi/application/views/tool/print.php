<table border="1" cellpadding="10" id="table" class="table table-bordered table-hover table-stripped display nowrap">
               
               <thead>
                 <th>No</th>
                 <th>No Anggota</th>
                 <th>No Polisi</th>
                 <th>No Uji Kir</th>
                 <th>Nama Pemilik</th>
                 <th>Alamat Pemilik</th>
                 <th>No HP</th>
                 <th>Merk</th>
                 <th>Warna/Tahun</th>
                 <th>No Rangka</th>
                 <th>No Mesin</th>
                 <th>Trayek</th>
                 <th>Keterangan</th>
               </thead>
               <?php $nomor=1; ?>
               <?php foreach ($anggota as $a): ?>
                 <tr>
                   <td><?= $nomor; ?></td>
                   <td><?= $a['no_anggota'] ?></td>
                   <td><?= $a['no_polisi'] ?></td>
                   <td><?= $a['no_uji_kir'] ?></td>
                   <td><?= $a['nama_pemilik'] ?></td>
                   <td><?= $a['alamat_pemilik'] ?></td>
                   <td><?= $a['no_hp'] ?></td>
                   <td><?= $a['merk_type'] ?></td>
                   <td><?= $a['warna_tahun'] ?></td>
                   <td><?= $a['no_rangka'] ?></td>
                   <td><?= $a['no_mesin'] ?></td>
                   <td><?= $a['trayek_jalur'] ?></td>
                   <td><?= $a['keterangan'] ?></td>
                   
                 </tr>
                 <?php $nomor++; ?>
               <?php endforeach ?>
              </table> 
             </div>      
      </div>
    </div>
    <script type="text/javascript">
    window.print();
  </script>