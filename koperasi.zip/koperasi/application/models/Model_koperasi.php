<?php 

class Model_koperasi extends CI_Model {

	public function getAllData()
	{

		return $this->db->get('tb_anggota');
	}

	public function tambah()
	{

		$data = [

			"no_anggota" => $this->input->post('no_anggota',true),
			"no_polisi" => $this->input->post('no_polisi',true),
			"no_uji_kir" => $this->input->post('no_uji_kir',true),
			"nama_pemilik" => $this->input->post('nama_pemilik',true),
			"alamat_pemilik" => $this->input->post('alamat_pemilik',true),
			"no_hp" => $this->input->post('no_hp',true),
			"merk_type" => $this->input->post('merk_type',true),
			"warna_tahun" => $this->input->post('warna_tahun',true),
			"no_rangka" => $this->input->post('no_rangka',true),
			"no_mesin" => $this->input->post('no_mesin',true),
			"trayek_jalur" => $this->input->post('trayek_jalur',true),
			"keterangan" => $this->input->post('keterangan',true)

		];

		$this->db->insert('tb_anggota',$data);
	}

	public function getAnggotaById($id)
	{

		$this->db->where('id',$id);
		return $this->db->get('tb_anggota')->result_array();
	}

	public function hapusanggota($id)
	{

		$this->db->where('id',$id);
		$this->db->delete('tb_anggota');
	}

	public function edit()
	{
		$data = [

			"no_anggota" => $this->input->post('no_anggota',true),
			"no_polisi" => $this->input->post('no_polisi',true),
			"no_uji_kir" => $this->input->post('no_uji_kir',true),
			"nama_pemilik" => $this->input->post('nama_pemilik',true),
			"alamat_pemilik" => $this->input->post('alamat_pemilik',true),
			"no_hp" => $this->input->post('no_hp',true),
			"merk_type" => $this->input->post('merk_type',true),
			"warna_tahun" => $this->input->post('warna_tahun',true),
			"no_rangka" => $this->input->post('no_rangka',true),
			"no_mesin" => $this->input->post('no_mesin',true),
			"trayek_jalur" => $this->input->post('trayek_jalur',true),
			"keterangan" => $this->input->post('keterangan',true)
		];



	$this->db->where('id',$this->input->post('id'));
	$this->db->update('tb_anggota', $data);
	}

	public function trayek()
	{

		$jalur = 'Padalarang - Rajamandala';
		$this->db->where('trayek_jalur',$jalur);
		return $this->db->get('tb_anggota')->result_array();
	}

}