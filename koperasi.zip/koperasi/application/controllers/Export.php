<?php 



class Export extends CI_Controller {

	public function __construct()
	{

		parent::__construct();

		$this->load->model('Model_koperasi');
	}

	public function excel()
	{

		$data['anggota'] = $this->Model_koperasi->getAllData()->result_array();

		header("Content-type: application/vnd-ms-excel");
		header("Content-Disposition: attachment; filename=Laporan Anggota.xls");

		
		$this->load->view('tool/export',$data);

		
	}

	public function print() 
	{
		$data['anggota'] = $this->Model_koperasi->getAllData()->result_array();
		
		$this->load->view('tool/print',$data);

	}
}