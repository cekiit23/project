<?php 


class Admin extends CI_Controller {

	public function __construct()
	{
		parent::__construct();

		$this->load->model('Model_koperasi');
	}

	public function index()
	{

		$data['judul'] = 'Halaman Utama';
		$data['anggota'] = $this->Model_koperasi->getAllData()->result_array();
		$this->load->view('templates/header',$data);
		$this->load->view('templates/sidebar');
		$this->load->view('admin/index',$data);
		$this->load->view('templates/footer');
	}

		
		public function tambah()
		{
			$data['judul'] = 'Tambah Data';

			$this->form_validation->set_rules('no_anggota','Nomor Anggota','required');
			$this->form_validation->set_rules('nama_pemilik','Nama Pemilik','required');
			$this->form_validation->set_rules('alamat_pemilik','Alamat Pemilik','required');
			$this->form_validation->set_rules('merk_type','Merk / Type','required');
			$this->form_validation->set_rules('warna_tahun','Warna / tahun','required');
			$this->form_validation->set_rules('no_rangka','Nomor Rangka','required');
			$this->form_validation->set_rules('no_mesin','Nomor Mesin','required');
			$this->form_validation->set_rules('trayek_jalur','Trayek / Jalur','required');
			$this->form_validation->set_rules('keterangan','keterangan','required');

			$this->form_validation->set_rules('no_polisi','nomor polisi','required');
			$this->form_validation->set_rules('no_uji_kir','nomor uji kir','required');
			$this->form_validation->set_rules('no_hp','nomor handphone','required|numeric');
		

			if($this->form_validation->run() == FALSE) 
			{
				$this->load->view('templates/header',$data);
				$this->load->view('templates/sidebar');
				$this->load->view('admin/tambah');
				$this->load->view('templates/footer');
			} else {
			$this->Model_koperasi->tambah();
			$this->session->set_flashdata('flash','ditambahkan');
			redirect('admin');
	}

			
		}

	public function hapus($id)
	{

		$this->Model_koperasi->hapusanggota($id);
		$this->session->set_flashdata('flash','dihapus');
		redirect('admin');
	}

	public function detail($id)
	{


		$data['anggota'] = $this->Model_koperasi->getAnggotaById($id);
		$data['judul'] = "Detail";
		$this->load->view('templates/header',$data);
		$this->load->view('templates/sidebar');
		$this->load->view('admin/detail',$data);
		$this->load->view('templates/footer');
	}

		public function edit($id)
		{
			$data['judul'] = 'Edit Data';

			$data['a'] = $this->Model_koperasi->getAnggotaById($id);

			$this->form_validation->set_rules('no_anggota','Nomor Anggota','required');
			$this->form_validation->set_rules('nama_pemilik','Nama Pemilik','required');
			$this->form_validation->set_rules('alamat_pemilik','Alamat Pemilik','required');
			$this->form_validation->set_rules('merk_type','Merk / Type','required');
			$this->form_validation->set_rules('warna_tahun','Warna / tahun','required');
			$this->form_validation->set_rules('no_rangka','Nomor Rangka','required');
			$this->form_validation->set_rules('no_mesin','Nomor Mesin','required');
			$this->form_validation->set_rules('trayek_jalur','Trayek / Jalur','required');
			$this->form_validation->set_rules('keterangan','keterangan','required');

			$this->form_validation->set_rules('no_polisi','nomor polisi','required');
			$this->form_validation->set_rules('no_uji_kir','nomor uji kir','required');
			$this->form_validation->set_rules('no_hp','nomor handphone','required|numeric');
		

			if($this->form_validation->run() == FALSE) 
			{
				$this->load->view('templates/header',$data);
				$this->load->view('templates/sidebar');
				$this->load->view('admin/edit',$data);
				$this->load->view('templates/footer');
			} else {
			$this->Model_koperasi->edit($id);
			$this->session->set_flashdata('flash','diubah');
			redirect('admin');
		}

	}

	public function hahaha()
	{

		var_dump($this->Model_koperasi->trayek() );
	}
}